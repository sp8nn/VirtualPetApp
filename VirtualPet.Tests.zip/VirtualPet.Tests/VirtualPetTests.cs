﻿using VirtualPetApp;
using Xunit;

namespace VirtualPetApp.Tests
{
    public class VirtualPetTests
    {
        [Fact]
        public void PetCanBeNamed()
        {
            VirtualPet pet = new VirtualPet("Fluffy");

            Assert.Equal("Fluffy", pet.Name);
        }

        [Fact]
        public void FeedLowersHunger()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 50;

            pet.Feed();

            Assert.Equal(30, pet.Hunger);
        }

        [Fact]
        public void FeedDoesNotMakeHungerNegative()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 10;

            pet.Feed();

            Assert.Equal(0, pet.Hunger);
        }

        [Fact]
        public void PlayRaisesHappiness()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Happiness = 50;

            pet.Play();

            Assert.Equal(65, pet.Happiness);
        }

        [Fact]
        public void PlayRaisesHunger()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 50;

            pet.Play();

            Assert.Equal(60, pet.Hunger);
        }

        [Fact]
        public void PassTimeRaisesHunger()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 50;

            pet.PassTime();

            Assert.Equal(60, pet.Hunger);
        }

        [Fact]
        public void PassTimeLowersHappiness()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Happiness = 50;

            pet.PassTime();

            Assert.Equal(45, pet.Happiness);
        }

        [Fact]
        public void PetStartsAsBaby()
        {
            VirtualPet pet = new VirtualPet("Fluffy");

            Assert.Equal("Baby", pet.GrowthStage);
        }

        [Fact]
        public void PetBecomesTeenAtAgeThree()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Age = 3;

            pet.UpdateGrowthStage();

            Assert.Equal("Teen", pet.GrowthStage);
        }

        [Fact]
        public void PetBecomesAdultAtAgeSix()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Age = 6;

            pet.UpdateGrowthStage();

            Assert.Equal("Adult", pet.GrowthStage);
        }

        [Fact]
        public void PetMoodBecomesHungry()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 80;

            pet.UpdateMood();

            Assert.Equal("Hungry", pet.Mood);
        }

        [Fact]
        public void PetMoodBecomesHappy()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 20;
            pet.Happiness = 80;

            pet.UpdateMood();

            Assert.Equal("Happy", pet.Mood);
        }

        [Fact]
        public void PetMoodBecomesSad()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 20;
            pet.Happiness = 20;

            pet.UpdateMood();

            Assert.Equal("Sad", pet.Mood);
        }

        [Fact]
        public void PetImageChangesWhenHappy()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Happiness = 90;
            pet.Hunger = 20;

            pet.UpdateMood();

            Assert.Contains("Happy", pet.GetImage());
        }

        [Fact]
        public void PetImageChangesWhenHungry()
        {
            VirtualPet pet = new VirtualPet("Fluffy");
            pet.Hunger = 90;

            pet.UpdateMood();

            Assert.Contains("Hungry", pet.GetImage());
        }
    }
}